import java.io.BufferedInputStream;
import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.Reader;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Comparator;
import java.util.List;
import java.util.Random;

/* Program: 1410_Final
 * Package: 
 * Module:  Wordpicker
 * Incept:  Apr 23, 2019
 * Author:  Scott Brown (skb)
 */

public class Wordpicker {
	Random rng;
	List<Word> wordList = new ArrayList<>();
	private final String wordListFile = "wordlist.txt";

	/** Load the word list and establish each word's difficulty rating
	 * 
	 */	
	public Wordpicker() {
		String line;
		String fileName = wordListFile;
		
		// seed the prng
		rng = new Random();
		
		// Load the word list (mostly Hunter's loader code)
        try {
			Reader fileReader = new InputStreamReader(FileUtil.getResourceByName(this.getClass(), fileName));
			BufferedReader bufferedReader = new BufferedReader(fileReader);
			while ((line = bufferedReader.readLine()) != null) {
			    wordList.add(new Word(line, wordScore(line)));
			}
			bufferedReader.close();
        } catch (FileNotFoundException ex) {
            System.err.println("File '" + fileName + "' not found");
        } catch (IOException ex) {
            System.err.println("Error reading file '" + fileName + "'");
            ex.printStackTrace();
        }
        
        setWordDifficulty2();
	}


	// Give each word a difficulty of 1 to 3
	// Variation 1
	// Rates solely on word score, very uneven distribution
	private void setWordDifficulty1() {
		int maxScore = 0;
		
		for (Word w : wordList)
			if (w.score > maxScore) maxScore = w.score;
        
        // Scale the word scores to a range of 1-3
        double f = 299.0 / maxScore;
    	//System.out.printf("max %d scale %g\n", maxScore, f);
        for (Word w : wordList) {
        	int s;
        	s = (int)(f * w.score) / 100 + 1;
        	//System.out.printf("score %d -> %d\n",  w.score, s);
        	if (s < 1 || s > 3) throw new RuntimeException("Cannot Happen: " + w.score + " " + s);
        	w.diff = s;
        }
	}
	
	// Give each word a difficulty of 1 to 3
	// Variation 2
	// Perfect distribution with no regard for scores
	private void setWordDifficulty2() {
		// re-sort the list on score
		wordList.sort(new WordScoreComparator());
		// divide it into evenly sized difficulty ranges		
		int a = wordList.size() * 1 / 3;
		int b = wordList.size() * 2 / 3;
		int c = wordList.size() * 3 / 3;
		int i = 0;		
		while (i < a) wordList.get(i++).diff = 1;
		while (i < b) wordList.get(i++).diff = 2;
		while (i < c) wordList.get(i++).diff = 3;
	}
	
	/** Select a random word of the specified difficulty. If no words of the requested
	 * difficulty are found, returns a random word of arbitrary difficulty.
	 * Returns null if the word list is empty.
	 * 
	 * @param difficulty Value of 1 (easy) 2 (medium) or 3 (difficult)
	 * @return The word
	 */
	public String chooseWord(int difficulty) {
		List<Word> words = new ArrayList<>();
		
		if (wordList.size() == 0) return null;	
		
		words = wordsOfDifficulty(difficulty);
		// If none qualify, choose from entire list
		if (words.size() == 0) words = wordList;
		// Pick one at random
		int n = rng.nextInt(words.size());
		return words.get(n).word;		
	}

	
	// Return a list of words of the specified difficulty
	private List<Word> wordsOfDifficulty(int diff) {
		List<Word> words = new ArrayList<>();
		for (Word w : wordList)
			if (w.diff == diff) words.add(w);
		return words;		
	}
	
	/** Compute the score for the given word (need not be in the list).
	 * Uses the Scrabble game's scoring system.
	 * 
	 * @param word for which to compute a score
	 * @return Score
	 */	
	static public int wordScore(String w) {
		// Recycle the Word type here, because why not
		// Letters and their scores, needs to be in alpha order for bsearch
		final Word[] tileScores = {
				new Word("A", 1 ), new Word("B", 3 ), new Word("C", 3 ), new Word("D", 2 ), new Word("E", 1 ),
				new Word("F", 4 ), new Word("G", 2 ), new Word("H", 4 ), new Word("I", 1 ), new Word("J", 8 ),
				new Word("K", 5 ), new Word("L", 1 ), new Word("M", 3 ), new Word("N", 1 ), new Word("O", 1 ),
				new Word("P", 3 ), new Word("Q", 10 ), new Word("R", 1 ), new Word("S", 1 ), new Word("T", 1 ),
				new Word("U", 1 ), new Word("V", 4 ), new Word("W", 4 ), new Word("X", 8 ), new Word("Y", 4 ),
				new Word("Z", 10 )
		};
		int score = 0;
		
		for (char c : w.toUpperCase().toCharArray()) {
			int i = Arrays.binarySearch(tileScores, new Word(c, 0));
			if (i >= 0) score += tileScores[i].score;
			// fixme: do something (what?) if letter is not found
		}
		return score;
	}
	
	
	
	// class for storing word/difficulty/score tuples
	static private class Word implements Comparable<Word> {
		protected String word;
		protected int score, diff;
		
		public Word(String w, int s) { 
			word = w; 
			score = s; 
			diff = 0; 
		}
		public Word(char c, int s) { 
			this("" + c, s); 
		}

		// Compare only on normal word sort order
		@Override
		public int compareTo(Word o) {
			return word.compareTo(o.word);
		}
	}

	static private class WordScoreComparator implements Comparator<Word> {
		@Override
		public int compare(Word o1, Word o2) { 
			return o1.score - o2.score;
		}
	}

	
	
	
	
	// fixme: debug routine
	public void info() {
	    System.out.printf("Total %d words\n", wordList.size());
	    for (int i = 1; i <= 3; i++) {
	    	List<Word> a = wordsOfDifficulty(i);
	    	int t = 0, mn, mx;
	    	mx = mn = a.get(0).score;
	    	for (Word w : a) {
	    		t += w.score;
	    		if (w.score < mn) mn = w.score;
	    		if (w.score > mx) mx = w.score;
	    	}
	    	System.out.printf("Total %d words at difficulty %d\n", a.size(), i);
	    	int md = a.get(a.size() / 2).score;	    	
	    	System.out.printf("\tScore min=%d max=%d avg=%f median=%d\n", mn, mx, (double)t / a.size(), md);
	    }
	}
	
	
}

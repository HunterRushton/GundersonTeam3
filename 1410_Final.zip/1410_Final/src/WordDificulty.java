

public enum WordDificulty {
Easy,Medium,Hard
}

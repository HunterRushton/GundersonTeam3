import java.util.Arrays;

/* Program: 1410_Final
 * Package: 
 * Module:  HMCore
 * Incept:  Apr 23, 2019
 * Author:  Scott Brown (skb)
 */

/** Hangman game core
 * 
 * @author skb
 *
 */
public class HMCore {
	static private String playerName;
	static private WordDificulty playerDiff;
	
	/** Launch the game */
	public static void main(String[] args) { 
		Wordpicker picker = new Wordpicker();
		HMGui gameUI = new HMGui();
		gameUI.setVisible(true);
		final int maximumMoves = gameUI.getMaximumMoves();
		
		// Get the player name and difficulty level
		playerName = gameUI.promptPlayerName();
		playerDiff = gameUI.promptPlayerDifficulty();
		
		do {
			WordGenerator wordTest = null;
			try {
				wordTest = new WordGenerator(playerDiff);
				wordTest.newWordWithDifficulty();
			} catch (Exception e) {
				throw new RuntimeException();
			}
			String word = wordTest.getWord();
			
			String unusedLetters = gameUI.getAlphabet();
			String guessedLetters = "";
			String maskedWord = maskWord(word, guessedLetters);
			int wrongMoves = 0;
			
			while (wrongMoves <= maximumMoves && maskedWord.indexOf('_') >= 0) {
				gameUI.setValidLetters(unusedLetters);
				gameUI.setWord(maskedWord);
				gameUI.setGuesses(guessedLetters);
				gameUI.setScore(wrongMoves);
				
				char c = gameUI.getLetter();
				
				int i = unusedLetters.indexOf(c);
				if (i < 0) throw new RuntimeException("Impossible Error!");
				// move guessed letter from unguessed to guessed
				unusedLetters = unusedLetters.substring(0,  i) + unusedLetters.substring(i + 1);
				guessedLetters += c;
				
				// if it was a wrong guess, bump the counter
				i = word.indexOf(c);
				if (i < 0) wrongMoves++;

				maskedWord = maskWord(word, guessedLetters);
			}			

			gameUI.setWord(word);  // reveal the word
			gameUI.setGuesses(guessedLetters);
			
			Leaderboard ldrbrd = new Leaderboard();
			ldrbrd.read();
			String scoreboardTitle = "";
			if (maskedWord.indexOf('_') < 0) {
				int score = Wordpicker.wordScore(word);
				ldrbrd.addScore(playerName, score);
				ldrbrd.write();
				scoreboardTitle = "You won! Great job!";
			} else {
				scoreboardTitle = "Oh no! You lost.";
			}
			gameUI.showScoreboard(ldrbrd, scoreboardTitle);

		} while (gameUI.promptYesNo("Another Game?", "Play Again"));

		gameUI.setVisible(false);		
	}
	
	/** Create a masked version of word based on GuessedLetters, so that any
	 * letter in GuessedLetters is shown, but any that aren't are replaced with
	 * underscore ('_'). Case insensitive.
	 * e.g mask("abcde", "bd") = "_b_d_"
	 * 
	 * @param word The word to mask off
	 * @param guessedLetters The letters that should not be masked
	 * @return The masked word
	 */	
	static private String maskWord(String word, String guessedLetters) {
		guessedLetters = guessedLetters.toUpperCase();
		char[] a = word.toCharArray();
		for (int i = 0; i < a.length; i++) {
			if (guessedLetters.indexOf(Character.toUpperCase(a[i])) < 0) a[i] = '_'; 
		}
		return new String(a);
	}

}

import java.util.ArrayList;
import java.util.Arrays;

/* Program: 1410_Final
 * Package: 
 * Module:  GuiTest
 * Incept:  Apr 7, 2019
 * Author:  Scott Brown (skb)
 */

public class GuiTest {
	
	public static void main(String[] args) {
		//leaderboardtest();
		//wordgeneratortest();
		//pickertest();
		guitest();
	}

	static public void leaderboardtest() {
		Leaderboard b = new  Leaderboard();
		b.read();
		ArrayList<ScoreEntry> s = b.getScores();
		System.out.printf("%d %s\n", s.size(), s);
		System.out.printf("done\n");				
	}

	static public void wordgeneratortest() {
		WordGenerator wordTest = null;
		int diffCount = WordDificulty.values().length;
		int count = 50;
		int[] score = new int[diffCount];
		Arrays.fill(score, 0);
		
		for (int i = 0; i < diffCount; i++) {
			int j;
			for (j = 0; j < count; j++) {
				try {
					wordTest = new WordGenerator(WordDificulty.values()[i]);
					wordTest.newWordWithDifficulty();
				} catch (Exception e) {
					throw new RuntimeException();
				}
				String w = wordTest.getWord();
				int s = Wordpicker.wordScore(w);
				score[i] += s;
				System.out.printf("%s %d\n", w, s);
			}
		}
		for (int i = 0; i < diffCount; i++)
			System.out.printf("diff=%s avg=%g\n", WordDificulty.values()[i], (double)score[i] / count);
		
		System.out.printf("done\n");				
	}
	
	static public void pickertest() {	
		Wordpicker a = new Wordpicker();
		int n; String s;
		
		a.info();
		
		n = a.wordScore(s = "a");
		System.out.printf("%s = %d\n", s, n);
		n = a.wordScore(s = "disenfranchisementationism");
		System.out.printf("%s = %d\n", s, n);
		System.out.printf("done\n");				
	}
	
	public static void guitest() {		
		HMGui t = new HMGui();
		t.setVisible(true);	
		t.setWord(t.getCommonAlphabet());
		t.setGuesses(t.getCommonAlphabet());
		
		// demo scoreboard
		Leaderboard ldrbrd = new Leaderboard();
		ldrbrd.read();
		t.showScoreboard(ldrbrd, "Test Title");
		
		// demo user info prompt
		System.out.printf("Prompting name...");
		String name = t.promptPlayerName();
		WordDificulty diff = t.promptPlayerDifficulty();
		System.out.printf("done; prompt got name=\"%s\" diff=%s\n", name, diff);
		
		// demo basic gui functions
		// loop user input, moving letters from valid-string to word-string, and cycling the score value		
		String unusedLetters = t.getAlphabet();
		String guessedLetters = "";
		int score = 0;
		for (;;) {
			t.setValidLetters(unusedLetters);
			t.setWord(guessedLetters);
			t.setGuesses(guessedLetters);
			t.setScore(score);
			if (++score > 6) score = 0;
			char c = t.getLetter();
			int i = unusedLetters.indexOf(c);
			if (i >= 0) {
				unusedLetters = unusedLetters.substring(0,  i) + unusedLetters.substring(i + 1);
				guessedLetters += c;
			}
		}
	}
}

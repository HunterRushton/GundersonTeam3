/* Program: 1410_Final
 * Package: 
 * Module:  FileUtil
 * Incept:  Apr 23, 2019
 * Author:  Scott Brown (skb)
 */

import java.io.BufferedInputStream;
import java.io.FileNotFoundException;
import java.io.InputStream;

/** Some generic file utility methods
 * 
 * @author skb
 *
 */
public class FileUtil {
	/** Finds the file we want, even from inside a jar file, and returns a read stream for it.
	 * The caller must be sure to call close on the stream when done.
	 * 
	 * @param context The caller's class (e.g. via this.getClass() or similar)
	 * @param name Name of the file relative to the calling class
	 * @return BufferedInputStream for the resource
	 */
	static public <T> BufferedInputStream getResourceByName(Class<T> context, String name) 
	throws FileNotFoundException
	{
		InputStream istream = context.getClassLoader().getResourceAsStream(name);
		if (istream == null) throw new FileNotFoundException(name);
		BufferedInputStream bistream = new BufferedInputStream(istream);
		return bistream;
	}
	


}

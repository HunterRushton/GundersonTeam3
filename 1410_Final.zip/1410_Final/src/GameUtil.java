import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;

import javax.swing.JFrame;
import javax.swing.JOptionPane;

/* Program: 1410_Final
 * Package: 
 * Module:  GameUtil
 * Incept:  Apr 18, 2019
 * Author:  Scott Brown (skb)
 */

public class GameUtil {
	
	// This is Noman's code
	public static void addCloseWindowConfirmation(JFrame theFrame) {
	       
        theFrame.setDefaultCloseOperation(JFrame.DO_NOTHING_ON_CLOSE);
        
        theFrame.addWindowListener(new WindowAdapter() {
            @Override
            public void windowClosing(WindowEvent we) {
                int prompt = JOptionPane.showConfirmDialog(null,
                        "Are you sure you want to quit?",
                        "Quit?", 
                        JOptionPane.YES_NO_OPTION);
                
                if (prompt == JOptionPane.YES_OPTION)
                    System.exit(0);
            }
        });
	}

}

import static org.junit.jupiter.api.Assertions.*;

import java.util.ArrayList;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

/* Program: 1410_Final
 * Package: 
 * Module:  tstHMGuiScoreboard
 * Incept:  Apr 9, 2019
 * Author:  Scott Brown (skb)
 */

class tstHMGuiScoreboard {
	HMGuiScoreboard scoreDialog;

	@BeforeEach
	void setUp() throws Exception {
		scoreDialog = new HMGuiScoreboard(null, false);
	}

	// all tests pass if no exceptions are thrown
	@Test
	void testSetScores1() {
	 	// tests with null data
		scoreDialog.setScores(null);
		scoreDialog.setVisible(true);
	}
	
	@Test
	void testSetScores2() {
		// test with long lists and oversize strings
		String sc_t[] = { "Thomas", "RichardExcessivelyLongUserName", "Harold", "Larry", "Moe", "Curly", "Jeb", "Alan", 
			"Carl", "Neil", "John", "Paul", "Ringo", "Freddy", "Waylon"	};
		int sc_i[] = { 3904, 8336, 9540, 2321, 8535, 4524, 5474, 5474, 6134, 3431, 5264, 100, 2071, 8564, 7912 };
		
		if (sc_t.length != sc_i.length) fail("Test frame error: Source arrays not balanced");		
		ArrayList<ScoreEntry> sel = new ArrayList<>();
		for (int i = 0; i < sc_t.length; i++)
			sel.add(new ScoreEntry(sc_t[i],  sc_i[i]));
			
		scoreDialog.setScores(sel);
		scoreDialog.setVisible(true);
	}
	
	@Test
	void testSetScores3() {
		// test with short lists
		String sc_t[] = { "Thomas", "Richard" };
		int sc_i[] = { 3904, 8336 };

		if (sc_t.length != sc_i.length) fail("Test frame error: Source arrays not balanced");		
		ArrayList<ScoreEntry> sel = new ArrayList<>();
		for (int i = 0; i < sc_t.length; i++)
			sel.add(new ScoreEntry(sc_t[i],  sc_i[i]));
		
		scoreDialog.setScores(sel); 
		scoreDialog.setVisible(true);
	}
	
//	@Test
//	void testSetScores4() {
//		// test with unbalanced arrays (names too long)
//		String sc_t[] = { "Thomas", "Richard", "Harold", "Larry", "Moe", "Curly", "Jeb", "Alan" }; 
//		int sc_i[] = { 3904, 8336 };
//		scoreDialog.setScores(sc_t, sc_i);
//		scoreDialog.setVisible(true);
//	}
//
//	@Test
//	void testSetScores5() {
//		// test with unbalanced arrays (scores too long)
//		String sc_t[] = { "Thomas", "Richard" };
//		int sc_i[] = { 3904, 8336, 9540, 2321, 8535, 4524, 5474, 5474, 6134, 3431, 5264, 100, 2071, 8564, 7912 };
//		scoreDialog.setScores(sc_t, sc_i);
//		scoreDialog.setVisible(true);
//	}

}

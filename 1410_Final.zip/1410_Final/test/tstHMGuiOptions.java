import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

/* Program: 1410_Final
 * Package: 
 * Module:  tstHMGuiOptions
 * Incept:  Apr 9, 2019
 * Author:  Scott Brown (skb)
 */

class tstHMGuiOptions {
	HMGuiOptions plrDialog;

	@BeforeEach
	void setUp() throws Exception {
		// This test requires interaction with the dialog, so opened as modal
		plrDialog = new HMGuiOptions(null, true);
	}
	
	@Test
	void testGetName_GetDiff() {
		// getDiff is dependent on getName having already run in the same instance
		plrDialog.setVisible(true);
		String n = plrDialog.getName();
		if (n == null) fail("User cancelled dialog");
		WordDificulty d = plrDialog.getDiff();
		if (d == null) fail("Difficulty out of range");		
	}


}
